#include "SearchesAndSorts.h"

void print_dice(int dice[], int size)
{
	int index = 0;

	for (; index < size; ++index)
	{
		printf("dice[%d]: %d\n", index, dice[index]);
	}
}

int sequential_search(int list[], int size, int target)
{
	int index = 0, found = 0;

	for (index = 0, found = 0; index < size && !found; ++index)
	{
		if (target == list[index]) // did we find the target
		{
			// yes, we found it
			found = 1;
		}
	}

	return found;
}

// removes all punctuation characters in the array called list
void remove_punct(char list[], int *size_ptr)
{
	int index = 0, punct_pos = 0, shift_index = 0;

	for (; index < *size_ptr; ++index)
	{
		if (ispunct(list[index]))
		{
			// yes, it's punctuation
			// we identified the index of the punctuation character
			// let's store the position
			punct_pos = index;

			for (shift_index = punct_pos + 1; 
				shift_index < *size_ptr; 
				++shift_index)
			{
				// let's shift all characters to the right of the punctuation
				// left to overwrite the punctuation
				list[shift_index - 1] = list[shift_index];
			}
			--(*size_ptr);
			--index; // this is to accommodate multiple punctuation characters
			         // in a row
		}
	}
}