#ifndef SEARCHES_SORTS_H
#define SEARCHES_SORTS_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <ctype.h>

void print_dice(int dice[], int size);

int sequential_search(int list[], int size, int target);

// removes all punctuation characters in the array called list
void remove_punct(char list[], int* size_ptr);

#endif