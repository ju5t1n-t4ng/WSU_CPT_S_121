// This example will illustrate how to work with arrays. We'll also
// study 4 algorithms that may be applied to arrays. The include:
//                 - sequential search
//                 - binary search
//                 - selection sort
//                 - bubble sort

// History: 3/3/25 - Implemented sequential_search (). Started discussing 
//                   binary_search ().
// 
//          2/28/25 - Implemented print_dice () and remove_punct ().
// 
//          2/26/25 - Introduced arrays. Discussed how to initialize them. Discussed
//                    in more depth the preincrement (++n) and postincrement (n++)
//                    operators. Implemented a loop to iterate through
//                    all of the items in the array. We also discovered
//                    that we can access any item in the array based on an
//                    index position.

#include "SearchesAndSorts.h"

int main(void)
{
	int dice[5] = { 5, 3, 2, 5, 3 } /* = {0}; */, index = 0, choice = 0, 
		size = 10 /* size of the char_arr [] */, 
		ids[5] = { 53, 45, 73, 12, 8 };
	char char_arr[10] = {'a', ',', 'b', 'c', 'd', ',', 'e', ':', '.', 'f'};

	printf("target: %d found: %d\n", 12, sequential_search(ids, 5, 12));
	printf("target: %d found: %d\n", 87, sequential_search(ids, 5, 87));
	printf("target: %.2d found: %d\n", 8, sequential_search(ids, 5, 8));


	remove_punct(char_arr, &size); // we'll pass the address of size to retain
	                           // the size changes after removing punctuation

	/*printf("++index: %d\n", ++index);
	printf("after preincrement index: %d\n", index);
	index = 0;
	printf("index++: %d\n", index++);
	printf("after postincrement index: %d\n", index);*/

	print_dice(dice, 5); // the name of an array is the address of element at
	                     // index 0

	// how to iterate through an array
	//for (index = 0; index < 5; ++index /* preincrement operator*/) // postincrement index++
	//{
	//	printf("%d - dice[%d]: %d\n", index + 1, index, dice[index]);
	//}

	//printf("Enter which die to reroll (1 - 5)? ");
	//scanf("%d", &choice);

	//dice[choice - 1] = 6; // random access to any of the items in the array by
	//                     // identifying the index

	//for (index = 0; index < 5; ++index /* preincrement operator*/) // postincrement index++
	//{
	//	printf("%d - dice[%d]: %d\n", index + 1, index, dice[index]);
	//}
	//
	return 0;
}