/* 
Programming Assignment 1: Equation Evaluator
Name: Justin Tang
Class: CptS 121, Spring 2025; Lab Section 8
Date: January 24, 2025
Description: Write a C program that evaluates the equations provided below. The program must
prompt the user for inputs to each equation and evaluate them based on the inputs.
*/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#define PI 3.14159


int main(void)
{

	char plaintext_character = 0, encoded_character = 0, A = 0;
	int a = 0;
	double force = 0, m = 0, acceleration = 0, 
		r = 0, h= 0, volume = 0,
		phosphate_atomic_mass = 0, hydrogen_mass = 1.008, oxygen_mass = 16, phosphorous_mass = 30.97,
		height = 0, time = 0, initial_height = 0, initial_velocity = 0,
		power = 0, resistance= 0, current = 0,
		x = 0, z = 0, y = 0;


	//Newton's Second Law of Motion
	//Promt user to enter mass and acceleration
	printf("Please enter the values for mass and acceleration (both floating-point values) for use in Newton's Second Law: ");
	scanf("%lf %lf", &m, &acceleration);
	//Calculate force
	force = m * acceleration;
	printf("Newton's Second Law: force = mass * acceleration = %.5lf * %.5lf = %.5lf\n", m, acceleration, force); 


	//Volume of a cylinder
	//Promt user to enter a radius and hieght
	printf("Please enter the values for radius and height (both floating-point values) for use in a volume for cylinder equation: ");
	scanf("%lf %lf", &r, &h);
	//Calculate for volume
	volume = PI * r * r * h;
	printf("Volume of cylinder: volume = PI * radius^2 * height = %.5lf * %.5lf^2 * %.5lf = %.5lf\n", PI, r, h, volume);


	//Character encoding
	//Prompt user to enter a plaintext character
	printf("Please enter a plaintext character for use in character encoding: ");
	scanf(" %c", &plaintext_character);
	//Calculate for encoded character
	encoded_character = (plaintext_character - '7') + 'A';
	printf("Character encoding: encoded character = (plaintext character - 7) + A = (%c - '7') + A = %c\n", plaintext_character, encoded_character);


	//Atomic mass of phosphate
	//Calculate for atomic mass of phosphate
	phosphate_atomic_mass = 3 * hydrogen_mass + 4 * oxygen_mass + phosphorous_mass;
	printf("Atomic mass of phosphate: phosphate atomic mass = 3 * hydrogen mass + 4 * oxygen mass + phosphorous mass = 3 * %lf + 4 * %lf + %lf = %lf\n", hydrogen_mass, oxygen_mass, phosphorous_mass, phosphate_atomic_mass);


	//Height of projectile in meters
	//prompt user to enter values for time, initial velocity, and initial height
	printf("Please enter the values for time, initial velocity, and initial height (all floating-point values) for use in a projectile height equation: ");
	scanf("%lf %lf %lf", &time, &initial_velocity, &initial_height);
	//calculate the height of projectile
	height = -16 * time * time + initial_velocity * time + initial_height;
	printf("Height of projectile in meters: height = -16 * time^2 + initial velocity * time + initial height = -16 * %lf^2 + %lf * %lf + %lf = %lf\n", time, initial_velocity, time, initial_height, height);


	//Current through circuit in Amperes
	//promt user to enter values for power and resistance
	printf("Please enter the values for power and resistance (both floating-point values) for use in a circuit current equation: ");
	scanf("%lf %lf", &power, &resistance);
	//caluclate the current
	current = sqrt(power / resistance);
	printf("Current through circuit in Amperes: current = square root of (power / resistance) = square root of (%lf / %lf) = %lf\n", power, resistance, current);

	
	//General equation
	//prompt the user to enter values for x, z, and a
	printf("Please enter the values for x and z (both floating-point values), and a (integer value) for use in a general equation: ");
	scanf("%lf %lf %d", &x, &z, &a);
	//calcualte the eqaution
	y = ((double) 3 / (double) 4) * x - z /((a % 2) + PI);
	printf("General equation: y =(3 / 4) * x - z / (a %% 2) + PI = (3 / 4) * %lf - %lf / (%d %% 2) + PI = %lf", x, z, a, y);


	return 0;
}