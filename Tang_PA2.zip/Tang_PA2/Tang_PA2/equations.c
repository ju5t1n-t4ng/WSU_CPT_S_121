/*
This file will contain all of the definitions and equations
for the functions declared in the program.
*/

#include "equations.h"


//Calculates force using newtons second law: f = m * a
double calculate_newtons_2nd_law(double mass, double acceleration) {
	return mass * acceleration;
}

//Calculates volume of a cylinder: V = PI * r^2 * h
double calculate_volume_cylinder(double radius, double height) {
	return PI * radius * radius * height;
}

//Encodes a inputed character based on ASCII
char encode_character(char plain_text_character) {
	return (plain_text_character - '7') + 'A';
}

//Calculates the atomic mass of phosphate
double calculate_atomic_mass(void) {
	return 3 * HYDROGEN_MASS + 4 * OXYGEN_MASS + PHOSPHOROUS_MASS;
}

//Calculates the height of a projectile
double calculate_height_projectile(double time, double initial_velocity, double initial_height) {
	return -16 * time * time + initial_velocity * time + initial_height;
}

//Calculates electrical current using sqrt(Power / Resistance)
double calculate_current(double power, double resistance) {
	return sqrt(power / resistance);
}

//Calculates the result of the general equation
double calculate_equation(double x, double z, int a) {
	return ((double)3 / (double)4) * x - z / ((a % 2) + PI);
}
