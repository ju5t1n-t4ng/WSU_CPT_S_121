/*
Programmer: Justin Tang
Course: CptS 121, Lab 8
Date: 1/27/2025
Description: This is the header file that contains all of the
#include and #define and function prototypes.
*/

#ifndef EQUATIONS_H
#define EQUATIONS_H

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

#define PI 3.14159 //Value of PI used in the calculation of the volume of a cylinder and the general equation
#define HYDROGEN_MASS 1.008 //Values for the set atomic massses used in calculating the mass of phosphate
#define OXYGEN_MASS 16.0
#define PHOSPHOROUS_MASS 30.97

//Function prototypes:

/*
Function: calculate_newtons_2nd_law()
Description: Calculates force using newton's second law: F = mass * acceleration
Preconditions: Mass and accerlartion are positive values
Postconditions: Returns the calculated force as a double
*/

double calculate_newtons_2nd_law(double mass, double acceleration);

/*
Function: calculate_volume_cylinder()
Description: Calculates the volume of a cylinder using the equation: V = PI * radius^2 * height
Preconditions: The radius and height are positive values
Postconditions: Returns the calculated force as a double
*/

double calculate_volume_cylinder(double radius, double height);

/*
Function: encode_character()
Description: Encodes a inputted character through ASCII
Preconditions: plain_text_character is a valid ASCII character
Postconditions: Returns the encoded character as a char
*/

char encode_character(char plain_text_character);

/*
Function: calculate_atomic_mass()
Description: Calculates the atomic mass of phosphate based on the elements phosphate is made up of
Preconditions: None, uses constants for atomic masses
Postconditions: Returns the calculated atomic mass as a double
*/

double calculate_atomic_mass(void);

/*
Function: calculate_height_projectile()
Description: Calculates the height of a projectile using:
             height = initial_height + initial_velocity * time - 0.5 * g * time^2
Preconditions: time, initial_velocity, and initial_height should be positive values
Postconditions: Returns the calculated height as a double
*/

double calculate_height_projectile(double time, double initial_velocity, double initial_height);

/*
Function: calculate_current()
Description : Calculates electric current using current = sqrt(Power / Resistance)
Preconditions : power and resistance are positive values
Postconditions : Returns the calculated current as a double
*/

double calculate_current(double power, double resistance);

/*
Function: calculate_equation()
Description: Calculates the result of a general equation involving x, z, and a
Preconditions: x and z are double values, and a is a integer
Postconditions: Returns the answer of the equation as a double
*/

double calculate_equation(double x, double z, int a);

#endif