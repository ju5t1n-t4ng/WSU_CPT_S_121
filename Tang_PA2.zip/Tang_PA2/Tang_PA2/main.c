/*
This file contains the main() function that will ask the user for
inputs and will allow it to be displayed.
*/

#include "equations.h"

int main(void)
{

	//Variables used for calculations in the equations
	double mass = 0, acceleration = 0, radius = 0, height = 0, time = 0, initial_velocity = 0, initial_height = 0, power = 0, resistance = 0, x = 0, z = 0;
	int a = 0;
	char plain_text_character = 0;

	//Newton's Second Law of Motion
	//Promt user to enter mass and acceleration
	printf("Please enter the values for mass and acceleration (both floating-point values) for use in Newton's Second Law: ");
	scanf("%lf %lf", &mass, &acceleration);
	//Output the force of Newton's Second Law calculation
	printf("Newton's Second Law: force = mass * acceleration = %.5lf * %.5lf = %.5lf\n\n", mass, acceleration, calculate_newtons_2nd_law( mass, acceleration));

	//Volume of a cylinder
	//Promt user to enter a radius and height
	printf("Please enter the values for radius and height (both floating-point values) for use in a volume for cylinder equation: ");
	scanf("%lf %lf", &radius, &height);
	//Output the calculated volume of the cylinder
	printf("Volume of cylinder: volume = PI * radius^2 * height = %.5lf * %.5lf^2 * %.5lf = %.5lf\n\n", PI, radius, height, calculate_volume_cylinder(radius, height));

	//Character encoding
	//Prompt user to enter a plaintext character
	printf("Please enter a plaintext character for use in character encoding: ");
	scanf(" %c", &plain_text_character);
	//Output the encoded charater
	printf("Character encoding: encoded character = (plaintext character - 7) + A = (%c - '7') + A = %c\n\n", plain_text_character, encode_character(plain_text_character));

	//Atomic mass of phosphate and the output
	printf("Atomic mass of phosphate: phosphate atomic mass = 3 * hydrogen mass + 4 * oxygen mass + phosphorous mass = 3 * %lf + 4 * %lf + %lf = %lf\n\n", calculate_atomic_mass());

	//Height of projectile in meters
	//prompt user to enter values for time, initial velocity, and initial height
	printf("Please enter the values for time, initial velocity, and initial height (all floating-point values) for use in a projectile height equation: ");
	scanf("%lf %lf %lf", &time, &initial_velocity, &initial_height);
	//Output the height of the projectile
	printf("Height of projectile in meters: height = -16 * time^2 + initial velocity * time + initial height = -16 * %lf^2 + %lf * %lf + %lf = %lf\n\n", time, initial_velocity, time, initial_height, calculate_height_projectile(time, initial_velocity, initial_height));

	//Current through circuit in Amperes
	//promt user to enter values for power and resistance
	printf("Please enter the values for power and resistance (both floating-point values) for use in a circuit current equation: ");
	scanf("%lf %lf", &power, &resistance);
	//Output the calculated current
	printf("Current through circuit in Amperes: current = square root of (power / resistance) = square root of (%lf / %lf) = %lf\n\n", power, resistance, calculate_current(power, resistance));

	//General equation
	//prompt the user to enter values for x, z, and a
	printf("Please enter the values for x and z (both floating-point values), and a (integer value) for use in a general equation: ");
	scanf("%lf %lf %d", &x, &z, &a);
	//Out put the result of the general equation
	printf("General equation: y =(3 / 4) * x - z / (a %% 2) + PI = (3 / 4) * %lf - %lf / (%d %% 2) + PI = %lf\n\n", x, z, a, calculate_equation(x, z, a));


	return 0;
}