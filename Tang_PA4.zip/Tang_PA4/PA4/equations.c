/*
Programmer: Justin Tang
Course: CptS 121, Lab 8
Date created: 2/20/2025
Date last modified: 2/28/2025
Description: Code to craps game.
*/

/*
This file will contain all of the definitions and equations
for the functions declared in the program.
*/


#include "headers.h"

/* 
Function: print_game_rules()
Description: Prints the rules of the game craps
Preconditions: game has not started yet
Postconditions:
*/

void print_game_rules(void) {
	printf("Welcome to the game of craps!\n");
	printf("Here are the rules:\n\n");
	printf("A player rolls two dice.Each die has six faces.\n");
	printf("These faces contain 1, 2, 3, 4, 5, and 6 spots.\n");
	printf("After the dice have come to rest, the sum of the spots on the two upward faces is calculated.\n");
	printf("If the sum is 7 or 11 on the first throw, the player wins. \n");
	printf("If the sum is 2, 3, or 12 on the first throw (called 'craps'), the player loses(i.e.the 'house' wins).\n");
	printf("If the sum is 4, 5, 6, 8, 9, or 10 on the first throw, then the sum becomes the player's 'point'.\n");
	printf("To win, you must continue rolling the dice until 'you make your point'.\n");
	printf("The player loses by rolling a 7 before making the point.\n\n");
	printf("Let's play craps!\n\n");
}

/*
Function: get_bank_balance()
Descritption Gets the starting bank balance of the player
Preconditions: The number entered is a positive floating point number
Postconditions: Returns the balance entered
*/
double get_bank_balance(void) {
	double balance;
	printf("Enter your balance: ");
	scanf("%lf", &balance);

	return balance;
}

/*
Function: get_wager_amount()
Description: Gets the amount the player would like to wager
Preconditions: The number entered is a positive floating point number
Postconditions: Returns the player's wager
*/
double get_wager_amount(void) {
	double wager;
	printf("Enter the amount you want to wager: ");
	scanf("%lf", &wager);

	return wager;
}

/*
Function: check_wager_amount()
Description: Checks if the wager is within the balance amount
Preconditions: Wager and balance are positive floating point number
Postconditions: returns 1 if wager is less than or eqaul to balance, otherwise 0
*/
int check_wager_amount(double wager, double balance) {
	return wager <= balance && wager > 0;
}

/*
Function: roll_die()
Description: rolls the die
Preconditions: srand()
postconditions: return a random number between 1 and 6
*/
int roll_die(void) {
	return rand() % 6 + 1;
}

/*
Function: Calculate_sum_dice()
Description: Finds the sum of 2 dice rolled
Preconditions: die values are positive integers and dice has been rolled twice
Postconditions: returns the sum of the dice rolled
*/
int calculate_sum_dice(int die1_value, int die2_value) {
	return die1_value + die2_value;
}

/*
Function: is_win_loss_or_point
Description: Determines the result of the first roll
Preconditions: dice has been rolled once
Postconditions: Returns 1 if the player won, 0 loss, otherwise -1
*/
int is_win_loss_or_point(int sum_dice) {
	if (sum_dice == 7 || sum_dice == 11)
		return 1;
	if (sum_dice == 2 || sum_dice == 3 || sum_dice == 12)
		return 0;

	return -1;
}

/*
Function: is_point_loss_or_neither()
Description: Determines the result of multiple rolls after eachother
Preconditions: Multiple dice rolled, did not lose or win on first roll, and the user has a point
Postconditions: Returns 1 if won, 0 los, otherwise -1
*/
int is_point_loss_or_neither(int sum_dice, int point_value) {
	if (sum_dice == point_value)
		return 1;
	if (sum_dice == 7)
		return 0;

	return -1;
}

/*
Function: adjust_bank_balance
Description: Adjusts the bank balance based on game
Preconditions:
Poscondtions: Returns the new bank balnce
*/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract) {
	if (add_or_subtract == 1) {
		bank_balance += wager_amount;
	}
	else if (add_or_subtract == 0) {
		bank_balance -= wager_amount;
	}
	return bank_balance;
}

/*
Function: chatter_meassages()
Description: Prints chatter messages
Preconditions: More than one turn has been played
Postcondtions:
*/
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance) {
	if (win_loss_neither == 1)
		printf("You won!!\n");
	else if (win_loss_neither == 0)
		printf("Sorry, you lost.\n");
	else {
		printf("You havent won yet, keep on going!\n");
	}


	printf("Rolls: %d, Initial Balance: $%.2f, Current Balance: $%.2f\n", number_rolls, initial_bank_balance, current_bank_balance);
}