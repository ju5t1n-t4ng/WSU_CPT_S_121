/*
This file contains the main() function that will ask the user for
inputs and will allow it to be displayed.
*/

#include "headers.h"

int main(void) {
    srand(time(NULL));

    print_game_rules();

    double bank_balance = get_bank_balance();
    double initial_balance = bank_balance;
    int number_rolls = 0, points_value = -1, result = -1;


    while (bank_balance > 0) {
        double wager;
        do {
            wager = get_wager_amount();
            if (!check_wager_amount(wager, bank_balance)) {
                printf("Invalid wager. Please enter a valid wager: \n");
            }
        } while (!check_wager_amount(wager, bank_balance));

        do {
            int die1 = roll_die();
            int die2 = roll_die();
            printf("Die: %d, %d\n", die1, die2);
            int sum_dice = calculate_sum_dice(die1, die2);
            number_rolls++;

            printf("You rolled a %d!\n", sum_dice);

            if (points_value == -1) {
               result = is_win_loss_or_point(sum_dice);
            }
            else {
                result = is_point_loss_or_neither(sum_dice, points_value);

           }

            if (result == -1 && points_value == -1) {
                points_value = sum_dice;
                printf("Your point is: %d\n", points_value);
            }
        } while (result == -1);

        bank_balance = adjust_bank_balance(bank_balance, wager, result);
        chatter_messages(number_rolls, result, initial_balance, bank_balance);

        if (result != -1) {
            // points_value = 0;
            printf("Do you want to play again? (1 for Yes, 0 for No): ");
            int play_again;
            if (scanf("%d", &play_again) != 1 || play_again == 0) {
                break;
            }
        }

        points_value = -1;
    }

    printf("Game over! Final balance: $%.2f\n", bank_balance);
    return 0;
}
