#include "headers.h"

/*
Programmer: Justin Tang
Course: CptS 121, Lab 8
Date created: 3/15/2025
Date last modified: 3/21/2025
Description: Code to yahhtzee game.
*/



/*
Function name: game_menu()
description: prints the yahtzee game menu
Parameters: none
Return: none
*/

void game_menu(void) {
	printf("\nYahtzee Game Menu:\n");
	printf("1. Print game rules\n");
	printf("2. Start a game of Yahtzee\n");
	printf("3. Exit\n\n");
	printf("Enter your choice: \n");
}

/*
Function name: print_game_rules()
description: prints the rules of the yahtzee game
Parameters: none
Return: none
*/

void print_game_rules(void) {
	printf("\nHere are the rules of Yahtzee:\n\n");
	printf("The scorecard used for Yahtzee is composed of two sections. A upper section and a lower section.\n");
	printf("A total of thirteen boxes or thirteen scoring combinations are divided amongst the sections.\n");
	printf("The upper section consists of boxes that are scored by summing the value of the dice matching the faces of the box.\n");
	printf("If a player rolls four 3's, then the score placed in the 3's box is the sum of the dice which is 12.\n");
	printf("Once a player has chosen to score a box, it may not be changed and the combination\n");
	printf("is no longer in play for future rounds.\n");
	printf("If the sum of the scores in the upper section is greater than or equal to 63,\n");
	printf("then 35 more points are added to the players overall score as a bonus.\n");
	printf("The lower section contains a number of poker like combinations.\n");
}

/*
Function name: wait_for_input()
description: gets user input
Parameters: none
Return: none
*/

void wait_for_input(void) {
	char input;
	scanf("%c", &input);
	scanf("%c", &input);
}


// array of names of combinations used to draw names of combinations
char* name_of_combinations[] = {
	"Sum of 1's\n", 
	"Sum of 2's\n", 
	"Sum of 3's\n", 
	"Sum of 4's\n",
	"Sum of 5's\n", 
	"Sum of 6's\n", 
	"Three-of-a-kind\n", 
	"Four-of-a-kind\n",
	"Full house\n", 
	"Small straight\n", 
	"Large straight\n", 
	"Yahtzee\n",
	"Chance\n"
};


/*
Function name: display_combinations()
description: displays the combinations that the player can select
preconditions: none
postconditions: none
*/


void display_combinations(void) {
	printf("\nSelect one of these combinations: \n");
	for (int i = 0; i < NUM_COMBINATIONS; i++) {
		printf("%d. %s", i + 1, name_of_combinations[i]);
	}
}


/*
Function name: main_game()
description: main game loop for yahtzee
preconditions: none
postconditions: none
*/

void main_game(void) {

	while (1) {
		printf("\nHit any key to continue: \n");
		wait_for_input();
		system("cls");
		break;
	}

	int round = 1;
	int currentplayer = 1;
	int player1scorecard[NUM_COMBINATIONS] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
	int player2scorecard[NUM_COMBINATIONS] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
	int player1totalscore = 0, player2totalscore = 0;
	int player1upperscore = 0, player2upperscore = 0;

	while (round <= 13) {
		printf("\nRound %d\n", round);
		printf("It is Player %d's turn.\n\n", currentplayer);

		//rolls 5 dices
		int dice[NUM_DICE];
		roll_five_die(dice);
		display_dice(dice);

		//3 rolls per round
		for (int roll = 1; roll <= 3; roll++) {
			char yes;

			printf("\nDo you want use this for a combination? (y/n)\n");
			scanf(" %c", &yes);
			getchar();

			if (yes == 'y') {
				display_combinations();
				int combinations;
				printf("\nEnter the combination (1-13): \n");
				scanf("%d", &combinations);

				if (combinations >= 1 && combinations <= 13) {
					if (player1scorecard[combinations - 1] != -1) {
						printf("\nCombination has been used. Please select another combination.\n\n");
						display_dice(dice);
						continue;
					}
					int score = calculate_combinations(dice, combinations);
					if (score > 0 || combinations == NUM_COMBINATIONS) {
						printf("\n%d points scored for combination %s\n", score, name_of_combinations[combinations - 1]);

						player1scorecard[combinations - 1] = score;
						player1totalscore = player1totalscore + score;

						if (combinations >= 1 && combinations <= 6) { //if combination used was in upper
							player1upperscore = player1upperscore + score;
						}
					}
					else {
						printf("\nInvalid combination choosen, 0 points.\n");
						player1scorecard[combinations - 1] = 0;
					}
					break;
				} else {
					printf("\nCombination is invalid. Please select another combination.\n\n");
					display_dice(dice);
				}
			} else if (yes == 'n') {
				if (roll < 3) {
					reroll_dice(dice);
					display_dice(dice);
				}
				else {
					display_combinations();
					int combinations;
					printf("\nEnter the combination (1-13): \n");
					scanf("%d", &combinations);
					if (combinations >= 1 && combinations <= 13) {
						if (player1scorecard[combinations - 1] != -1) {
							printf("\nCombination has been used. Please select another combination.\n\n");
							display_dice(dice);
							continue;
						}
						int score = calculate_combinations(dice, combinations);
						if (score > 0 || combinations == NUM_COMBINATIONS) {
							printf("\n%d points scored for combination %s\n", score, name_of_combinations[combinations - 1]);

							player1scorecard[combinations - 1] = score;
							player1totalscore = player1totalscore + score;

							if (combinations >= 1 && combinations <= 6) { //if combination used was in upper
								player1upperscore = player1upperscore + score;
							}
						}
						else {
							printf("\nInvalid combination choosen, 0 points.\n");
							player1scorecard[combinations - 1] = 0;
						}
					}
					else {
						printf("\nInvalid combination entered. Try again.\n");
					}
				}
			}
			else {
				printf("\nInvalid input. Try again.\n");
			}
		}

		printf("Switching Players.\n");
		printf("It is now Player 2's turn.\n\n");

		roll_five_die(dice);
		display_dice(dice);

		//3 rolls per round
		for (int roll = 1; roll <= 3; roll++) {
			char yes;

			printf("\nDo you want use this for a combination? (y/n)\n");
			scanf(" %c", &yes);
			getchar();

			if (yes == 'y') {
				display_combinations();
				int combinations;
				printf("\nEnter the combination (1-13): \n");
				scanf("%d", &combinations);
				if (combinations >= 1 && combinations <= 13) {
					if (player2scorecard[combinations - 1] != -1) {
						printf("\nCombination has been used. Please select another combination.\n\n");
						display_dice(dice);
						continue;
					}
					int score = calculate_combinations(dice, combinations);
					if (score > 0 || combinations == NUM_COMBINATIONS) {
						printf("\n%d points scored for combination %s", score, name_of_combinations[combinations - 1]);

						player2scorecard[combinations - 1] = score;
						player2totalscore = player2totalscore + score;

						if (combinations >= 1 && combinations <= 6) { //if combination used was in upper
							player2upperscore = player2upperscore + score;
						}
					}
					else {
						printf("\nInvalid combination choosen, 0 points.\n");
						player2scorecard[combinations - 1] = 0;
					}
					break;
				}
				else {
					printf("\nInvalid combination entered. Try again. \n");
					display_dice(dice);
				}
			}
			else if (yes == 'n') {
				if (roll < 3) {
					reroll_dice(dice);
					display_dice(dice);
				}
				else {
					display_combinations();
					int combinations;
					printf("\nEnter the combination (1-13): \n");
					scanf("%d", &combinations);
					if (combinations >= 1 && combinations <= 13) {
						if (player2scorecard[combinations - 1] != -1) {
							printf("\nCombination has been used. Please select another combination.\n\n");
							display_dice(dice);
							continue;
						}
						int score = calculate_combinations(dice, combinations);
						if (score > 0 || combinations == NUM_COMBINATIONS) {
							printf("\n%d points scored for combination %s", score, name_of_combinations[combinations - 1]);

							player2scorecard[combinations - 1] = score;
							player2totalscore = player2totalscore + score;

							if (combinations >= 1 && combinations <= 6) { //if combination used was in upper
								player2upperscore = player2upperscore + score;
							}
						}
						else {
							printf("\nInvalid combination choosen, 0 points.\n");
							player2scorecard[combinations - 1] = 0;
						}
					}
					else {
						printf("\nInvalid combination entered. Try again.\n");
						display_dice(dice);
					}
				}
			}
			else {
				printf("\nInvalid input. Try again.\n");
			}
		}
		printf("\nHit any key to continue to next round: \n");
		wait_for_input();
		system("cls");
		round++;
	}

	printf("\nGAME IS OVER!\n");
	printf("\nPlayer 1 Upper Score: %d\n", player1upperscore);
	printf("Player 2 Upper Score: %d\n", player2upperscore);

	calculate_bonus(&player1upperscore, &player1totalscore);
	calculate_bonus(&player2upperscore, &player2totalscore);

	final_scores(player1totalscore, player2totalscore);

	printf("\nPress any key to return to main menu: \n");
	wait_for_input();
	system("cls");
}

/*
Function name: roll_five_die()
description: rolls 5 dice
Parameters: int dice[]
Return: none
*/

void roll_five_die(int dice[]) {
	for (int i = 0; i < NUM_DICE; i++) {
		dice[i] = rand() % 6 + 1;
	}
}

/*
Function name: display_dice()
description: displays the dice
Parameters: int dice[]
Return: none
*/

void display_dice(int dice[]) {
	for (int i = 0; i < NUM_DICE; i++) {
		printf("Die number %d: %d\n", i + 1, dice[i]);
	}
}

/*
Function name: reroll_dice()
description: rerolls the dice
Parameters: int dice[]
*/

void reroll_dice(int dice[]) {
	printf("\nPlease enter what die you would like to reroll: ");
	char input[20];
	fgets(input, sizeof(input), stdin);

	for (int i = 0; input[i] != '\0'; i++) {
		if (input[i] >= '1' && input[i] <= '5') {
			int die = input[i] - '0';
			dice[die - 1] = rand() % 6 + 1;
		}
	}
}

//array to calculate the combinations
int (*functions_combinations[])(int[]) = {
	calculate_upper_section, calculate_upper_section, calculate_upper_section,
	calculate_upper_section, calculate_upper_section, calculate_upper_section,
	calculate_three_of_a_kind,
	calculate_four_of_a_kind,
	check_full_house,
	check_small_straight,
	check_large_straight,
	check_yahtzee,
	calculate_chance
};

/*
Function name: calculate_combinations()
description: calculates the combinations at points
Parameters: int dice[], int combination
Return: points appropraite for the combination
*/

int calculate_combinations(int dice[], int combination) {
	if (combination >= 1 && combination <= 6) {
		return calculate_upper_section(dice, combination);
	}
	else if (combination >= 7 && combination <= NUM_COMBINATIONS) {
		return functions_combinations[combination - 1](dice);
	}
	return 0;
}

/*
Function name: calculate_upper_section()
description: calculates the upper section of the game based offof the dice values
Parameters: int dice[], int value
Return: sum of the dice values that match the value of the dice
*/

int calculate_upper_section(int dice[], int value) {
	int sum = 0;
	for (int i = 0; i < NUM_DICE; i++) {
		if (dice[i] == value) {
			sum += value; //adds similar dice values
		}
	}
	return sum;
}

/*
Function name: calculate_three_of_a_kind()
description: calculates the sum of the dice if there is a three of a kind
Parameters: int dice[]
Return: sum of the dice if there is a three of a kind

*/

int calculate_three_of_a_kind(int dice[]) {
	int sum = 0;
	int count[6] = { 0 };

	for (int i = 0; i < NUM_DICE; i++) {
		count[dice[i] - 1]++;
	}
	for (int i = 1; i < 6; i++) { //checks for 3 of a kind
		if (count[i] >= 3)
		{
			sum = dice[0] + dice[1] + dice[2] + dice[3] + dice[4];
		}
		return sum;
	}
	return 0;
}

/*
Function name: calculate_four_of_a_kind()
description: calculates the sum of the dice if there is a four of a kind
Parameters: int dice[]
Return: sum of the dice if there is a four of a kind
*/


int calculate_four_of_a_kind(int dice[]) {
	int count[6] = { 0 };

	for (int i = 0; i < NUM_DICE; i++) {
		count[dice[i] - 1]++;
	}
	for (int i = 0; i < 6; i++) { //checks for 4 of a kind
		if (count[i] >= 4)
		{
			return dice[0] + dice[1] + dice[2] + dice[3] + dice[4];
		}
	}
	return 0;
}

/*
Function name: check_full_house()
description: checks for a full house in the dice values
Parameters: int dice[]
Return: 25 points if there is a full house
*/


int check_full_house(int dice[]) {
	int count[6] = { 0 }, check3 = 0, check2 = 0, points = 0;

	for (int i = 0; i < NUM_DICE; i++) {
		count[dice[i] - 1]++;
	}
	for (int i = 0; i < 6; i++) { //checks for 3 of a kind
		if (count[i] == 3)
		{
			check3 = 3;
		}
		else if (count[i] == 2) { //checks for 2 of a kind
			check2 = 2;
		}
	}
	if (check3 == 3 && check2 == 2) {
		points = 25;
	}
	return points;
}

/*
Function name: check_small_straight()
description: checks for a small straight in the dice values
Parameters: int dice[]
Return: 30 points if there is a small straight
*/

int check_small_straight(int dice[]) {
	int index = 0, temp = 0, passes = 0;
	for (passes = 1; passes < NUM_DICE; ++passes) { //bubblesort from Andy's lec
		for (index = 0; index < NUM_DICE - passes; ++index) {
			if (dice[index] > dice[index + 1]) 
			{
				temp = dice[index];
				dice[index] = dice[index + 1];
				dice[index + 1] = temp;
			}
		}
	}
	//detect for small striaght
	for (int i = 0; i < NUM_DICE - 3; i++) {
		if (dice[i] + 1 == dice[i + 1] && dice[i] + 2 == dice[i + 2] && dice[i] + 3 == dice[i + 3]) {
			return 30;
		}
	}
	return 0;
}

/*
Function name: check_large_straight()
description: checks for a large straight in the dice values
Parameters: int dice[]
Return: 40 points if there is a large straight

*/


int check_large_straight(int dice[]) {
	int index = 0, temp = 0, passes = 0;
	for (passes = 1; passes < NUM_DICE; ++passes) { //bubblesort from Andy's lec
		for (index = 0; index < NUM_DICE - passes; ++index) {
			if (dice[index] > dice[index + 1])
			{
				temp = dice[index];
				dice[index] = dice[index + 1];
				dice[index + 1] = temp;
			}
		}
	}
	//detect for large striaght
	for (int i = 0; i < NUM_DICE - 4; i++) {
		if (dice[i] + 1 == dice[i + 1] && dice[i] + 2 == dice[i + 2] && dice[i] + 3 == dice[i + 3] && dice[i] + 4 == dice[i + 4]) {
			return 40;
		}
	}
	return 0;
}

/*
Function name: check_yahtzee()
description: checks for a yahtzee in the dice values
Parameters: int dice[]
Return: 50 points if there is a yahtzee
*/

int check_yahtzee(int dice[]) {
	int count = 0;
	for (int i = 0; i < NUM_DICE; i++) {
		if (dice[i] == dice[0]) { //compares dice values
			count++;
		}
	}
	if (count == NUM_DICE) { //check there is 5 dice of same value
		return 50;
	}
	return 0;
}

/*
Function name: calculate_chance()
description: calculates the sum of the dice values
Parameters: int dice[]
Return: sum of the dice
*/

int calculate_chance(int dice[]) {
	int sum = 0;
	sum = dice[0] + dice[1] + dice[2] + dice[3] + dice[4]; //add current dice
	return sum;
}

/*
Function name: calculate_bonus()
description: calculates the bonus points for the player based off of the upper score
Parameters: int *upperscore, int *totalscore
Return: none
*/

void calculate_bonus(int *upperscore, int *totalscore) {
	if (*upperscore >= 63) {
		*totalscore += 35; //add thirty five ontop of the original score
	}
}

/*
Function name: final_scores()
description: prints the final scores of the two player in the game
Parameters: int player1totalscore, int player2totalscore
Return: none
*/

void final_scores(int player1totalscore, int player2totalscore) {
	printf("\nFINAL SCORES!\n");
	printf("Player 1 Total Score: %d\n", player1totalscore);
	printf("Player 2 Total Score: %d\n", player2totalscore);

	//print winner
	if (player1totalscore > player2totalscore) {
		printf("\nThe winner is player 1!\n");
	}
	else if (player2totalscore > player1totalscore) {
		printf("\nThe winner is player 2!\n");
	}
	else {
		printf("It is a tie!\n");
	}
}