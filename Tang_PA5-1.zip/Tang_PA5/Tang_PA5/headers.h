#ifndef headers_h
#define headers_h

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

#define NUM_DICE 5
#define NUM_COMBINATIONS 13

void game_menu(void);
void print_game_rules(void);
void wait_for_input(void);

void main_game(void);

void roll_five_die(int dice[]);
void display_dice(int dice[]);
void reroll_dice(int dice[]);

void display_combinations(void);
int calculate_combinations(int dice[], int combination);
int calculate_upper_section(int dice[], int value);
int calculate_three_of_a_kind(int dice[]);
int calculate_four_of_a_kind(int dice[]);
int check_full_house(int dice[]);
int check_small_straight(int dice[]);
int check_large_straight(int dice[]);
int check_yahtzee(int dice[]);
int calculate_chance(int dice[]);

void calculate_bonus(int* upperscore, int* totalscore);
void final_scores(int player1_score, int player2_score);





#endif