#include "headers.h"

int main(void)
{
	// print game menu and recieve choice
	srand(time(NULL));
	int choice;
	do {
		game_menu();
		scanf("%d", &choice);
		system("cls");
		switch (choice) {
		case 1:
			print_game_rules();
			break;
		case 2:
			main_game();
			break;
		case 3:
			printf("Goodbye!\n");
			break;
		default:
			printf("Invalid option, try again.\n");
		}
	} while (choice != 3);
	
	return 0;
}